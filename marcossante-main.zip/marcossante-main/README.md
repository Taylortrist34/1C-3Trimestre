#sobre mim
👋ola meu nome e @marcossante
:+1:�meu imail de contato e marcos.sante@escola.pr.gov.br
- 👀  eu estou interessado em aprender a programar novas linguagens 
-  🌱 eu estou aprendendo recentemente a  linguagem de javascript e scratch
 
